using UnityEngine;

public enum ItemType
{
    Curacion,
    Escudo,
    Velocidad,
    SaltoDoble
}

[CreateAssetMenu(fileName = "NewItem", menuName = "Items/Item Data")]
public class ItemData : ScriptableObject
{
    [Header("Informaci�n")]
    public string itemName;
    [TextArea] public string description;

    [Header("Prefab del �tem")]
    public GameObject itemPrefab;

    [Header("Configuraci�n del efecto")]
    public ItemType itemType;
    public float duration = 5f;
    public float effectValue = 2f;
}
